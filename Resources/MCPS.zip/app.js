Ti.UI.setBackgroundColor('#ffffff');

var mcps = {}; // project namespace

mcps.ui = require('ui'); // import ui namespace

var win = mcps.ui.createApplicationWindow();
win.open();


